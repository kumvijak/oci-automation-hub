# Copyright (c) 2024, 2026, Oracle and/or its affiliates. All rights reserved.
# The Universal Permissive License (UPL), Version 1.0 as shown at https://oss.oracle.com/licenses/upl/
terraform {
  required_version = ">= 1.5.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 8.16.0"
    }
  }
}

provider "oci" {
  region = var.region
}

locals {
  app_port                    = 8000
  min_port                    = 443
  max_port                    = 8080
  certificate_pem             = file("${path.module}/modules/certificates/wildcard-app.crt")
  certificate_chain_pem       = file("${path.module}/modules/certificates/wildcard-ca.crt")
  certificate_private_key_pem = file("${path.module}/modules/certificates/wildcard-app.key")
  image_version               = length(regexall(":[^/]+$", var.app_image_url)) > 0 ? trimprefix(regexall(":[^/]+$", var.app_image_url)[0], ":") : "latest"
  effective_app_base_url      = "https://${module.app_load_balancer.public_ip}"
}

resource "oci_core_network_security_group" "lb" {
  compartment_id = var.compartment_ocid
  vcn_id         = var.vcn_id
  display_name   = "${var.app_name_prefix}-lb-nsg"
}

resource "oci_core_network_security_group" "containers" {
  compartment_id = var.compartment_ocid
  vcn_id         = var.vcn_id
  display_name   = "${var.app_name_prefix}-containers-nsg"
}

resource "oci_core_network_security_group_security_rule" "lb_https_ingress" {
  network_security_group_id = oci_core_network_security_group.lb.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = "0.0.0.0/0"
  source_type               = "CIDR_BLOCK"

  tcp_options {
    destination_port_range {
      min = 443
      max = 443
    }
  }
}

resource "oci_core_network_security_group_security_rule" "lb_to_app_egress" {
  network_security_group_id = oci_core_network_security_group.lb.id
  direction                 = "EGRESS"
  protocol                  = "6"
  destination               = oci_core_network_security_group.containers.id
  destination_type          = "NETWORK_SECURITY_GROUP"

  tcp_options {
    destination_port_range {
      min = local.app_port
      max = local.app_port
    }
  }
}


resource "oci_core_network_security_group_security_rule" "app_from_lb_ingress" {
  network_security_group_id = oci_core_network_security_group.containers.id
  direction                 = "INGRESS"
  protocol                  = "6"
  source                    = oci_core_network_security_group.lb.id
  source_type               = "NETWORK_SECURITY_GROUP"

  tcp_options {
    destination_port_range {
      min = local.app_port
      max = local.app_port
    }
  }
}

resource "oci_core_network_security_group_security_rule" "app_from_app_ingress" {
  network_security_group_id = oci_core_network_security_group.containers.id
  direction                 = "INGRESS"
  protocol                  = "all"
  source                    = "0.0.0.0/0"
  source_type               = "CIDR_BLOCK"
}

resource "oci_core_network_security_group_security_rule" "containers_egress" {
  network_security_group_id = oci_core_network_security_group.containers.id
  direction                 = "EGRESS"
  protocol                  = "all"
  destination               = "0.0.0.0/0"
  destination_type          = "CIDR_BLOCK"
}

module "app_certificate" {
  source           = "./modules/certificate-import"
  compartment_id   = var.compartment_ocid
  certificate_name = "${var.app_name_prefix}-wc-cert"
  certificate_pem  = local.certificate_pem
  cert_chain_pem   = local.certificate_chain_pem
  private_key_pem  = local.certificate_private_key_pem
}

module "app_load_balancer" {
  source         = "./modules/load-balancer"
  compartment_id = var.compartment_ocid
  app_name       = "${var.app_name_prefix}-lb"
  subnet_id      = var.lb_subnet_id
  backend_port   = local.app_port
  certificate_id = module.app_certificate.certificate_id
  nsg_ids        = [oci_core_network_security_group.lb.id]
}

module "identity_domain_app" {
  source               = "./modules/identity-domain-app"
  identity_domain_ocid = var.identity_domain_ocid
  app_base_url         = local.effective_app_base_url
  app_name             = "${var.app_name_prefix}-app"
}

module "test_container_instance" {
  source                 = "./modules/container-instance"
  ocpus                  = var.ocpus
  memory_in_gbs          = var.memory_in_gbs
  shape                  = var.shape
  compartment_id         = var.compartment_ocid
  availability_domain    = var.availability_domain
  subnet_id              = var.app_subnet_id
  app_name               = "${var.app_name_prefix}-app-server"
  image_url              = var.app_image_url
  image_version          = local.image_version
  app_base_url           = local.effective_app_base_url
  identity_domain_issuer = module.identity_domain_app.identity_domain_issuer
  oidc_client_id         = module.identity_domain_app.client_id
  oidc_client_secret     = module.identity_domain_app.client_secret
  assign_public_ip       = var.assign_public_ip
  nsg_ids                = [oci_core_network_security_group.containers.id]
}

module "app_load_balancer_backend" {
  source             = "./modules/load-balancer-backend"
  load_balancer_id   = module.app_load_balancer.load_balancer_id
  backendset_name    = module.app_load_balancer.backend_set_name
  backend_ip_address = module.test_container_instance.private_ip
  backend_port       = local.app_port
}

module "cloudops_mcp_server" {
  source                          = "./modules/cloudops-mcp"
  tenancy_ocid                    = var.tenancy_ocid
  region                          = var.region
  compartment_id                  = var.compartment_ocid
  availability_domain             = var.availability_domain
  container_instance_display_name = "${var.app_name_prefix}-mcp-server-instance"
  container_image_url             = var.cloudops_mcp_image_url
  container_display_name          = "${var.app_name_prefix}mcp-server-container"
  shape                           = var.shape
  ocpus                           = var.ocpus
  memory_in_gbs                   = var.memory_in_gbs
  subnet_id                       = var.app_subnet_id
  assign_public_ip                = var.assign_public_ip
  nsg_ids                         = [oci_core_network_security_group.containers.id]
}

module "secops_mcp_server" {
  source                          = "./modules/secops-mcp"
  compartment_id                  = var.compartment_ocid
  availability_domain             = var.availability_domain
  container_instance_display_name = "${var.app_name_prefix}-secops-mcp-server-instance"
  container_image_url             = var.secops_mcp_image_url
  container_display_name          = "${var.app_name_prefix}secops-mcp-server-container"
  shape                           = var.shape
  ocpus                           = var.ocpus
  memory_in_gbs                   = var.memory_in_gbs
  subnet_id                       = var.app_subnet_id
  assign_public_ip                = var.assign_public_ip
  nsg_ids                         = [oci_core_network_security_group.containers.id]
  oci_compartment_id              = var.compartment_ocid
  oci_log_analytics_namespace     = var.log_analytics_namespace
  oci_la_log_group_audit          = var.la_log_group_audit
  oci_la_log_group_vcn_flow       = var.la_log_group_vcn_flow
  oci_la_log_group_lb             = var.la_log_group_lb
  oci_la_log_group_bucket         = var.la_log_group_bucket
  oci_la_log_group_dns            = var.la_log_group_dns
  oci_la_log_group_vm_app         = var.la_log_group_vm_app
}
